from rest_framework import serializers
from financeiro.models import Gestao_Finaceira

class Gestao_FinaceiraSerializer(serializers.ModelSerializer):
    class Meta:

        model = Gestao_Finaceira
        fields = '__all__'
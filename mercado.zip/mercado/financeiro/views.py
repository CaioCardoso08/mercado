from rest_framework import viewsets
from financeiro.models import Gestao_Finaceira
from financeiro.serializers import Gestao_FinaceiraSerializer

class Gestao_FinaceiraViewSet(viewsets.ModelViewSet):
    queryset = Gestao_Finaceira.objects.all()
    serializer_class = Gestao_FinaceiraSerializer
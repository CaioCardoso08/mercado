from django.db import models

class Gestao_Finaceira(models.Model):

    id_Gestao_Finaceira = models.AutoField (primary_key=True)
    vendas = models.CharField(max_length=100)
    preço = models.CharField(max_length=100)
    quantidades_vendidas = models.CharField(max_length=100)
    tipo = models.CharField(max_length=11)
    metodo_de_venda = models.CharField(max_length=11)

def __str__(self):
    return self.nome_Funcionario
from django.contrib import admin
from financeiro.models import Gestao_Finaceira
admin.site.register(Gestao_Finaceira)
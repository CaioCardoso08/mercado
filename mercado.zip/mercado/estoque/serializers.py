from rest_framework import serializers
from estoque.models import estoques

class estoquesSerializer(serializers.ModelSerializer):
    class Meta:

        model = estoques
        fields = '__all__'
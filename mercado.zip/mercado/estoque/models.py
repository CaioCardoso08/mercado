from django.db import models

class estoques(models.Model):

    id_estoques = models.AutoField (primary_key=True)
    valor = models.CharField(max_length=100)
    codigo_mercadoria = models.CharField(max_length=100)
    nome_mercadoria = models.CharField(max_length=100)
    quantidade = models.CharField(max_length=100)
    tipo = models.CharField(max_length=100)
    vecimento_mercadoria = models.CharField(max_length=11)
    fornecedor = models.CharField(max_length=11)

def __str__(self):
    return self.nome_Funcionario
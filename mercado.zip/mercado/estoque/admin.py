from django.contrib import admin
from estoque.models import estoques
admin.site.register(estoques)
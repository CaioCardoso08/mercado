from rest_framework import viewsets
from estoque.models import estoques
from estoque.serializers import estoquesSerializer

class estoquesViewSet(viewsets.ModelViewSet):
    queryset = estoques.objects.all()
    serializer_class = estoquesSerializer